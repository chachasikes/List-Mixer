// $Id$

Drupal.behaviors.listmixer.pushBehavior = function() {
  this.init = function() {
  }

  /* Library Functions */  
  this.textPush = function() {
  }
  
  this.nodereferencePush = function() {
  }

  this.linkPush = function() {
  }

  this.filefieldPush = function() {
  }

  this.termPush = function() {
  }
}



