// $Id$
Drupal.behaviors.listmixer.activateBehavior = function(preset) {
  this.init = function() {
   // alert('Activate Library Loaded');
  }

  /* Library Functions */  
  this.buttonActivate = function() {
  }
  
  this.selectActivate = function(preset) {
    Drupal.behaviors.listmixer.selectable(preset);
  }
    
  this.dragActivate = function() {
  }
  
  this.loadActivate = function() {
  }
  this.markup = { 
    loadActivate : '',
    buttonActivate : '<div class="listmixer-activate-button"><button class="button"><div class="listmixer-activate-label">Activate</div></button></div><div class="listmixer-deactivate-button"><button class="button"><div class="listmixer-deactivate-label">Deactivate</div></button></div>',
    selectActivate : '',
  };
}

/**
 * Add selectable capabilities to target id
 */
Drupal.behaviors.listmixer.selectable = function(preset) {
  if(preset.activation === false) {
    $(preset.interactions.interactions_target_id).attr("id", "selectable");
    	$(function() {
        	$(preset.interactions.interactions_target_id + "#selectable").selectable({ 
           // filter : preset.interactions.interactions_target_id_element,
            selected: function(event, ui) { 
            // @TODO test the different ways of useing the ui object to figure out the value of what was selected.
            // This will only support paths for the moment.
            //if (preset.interactions.interactions_target_id_attr === 'href' ) {
              if(ui.selected.pathname !== undefined) {
                preset.targetIdArray.push(ui.selected.pathname);
              }
              preset.activation = true;
              Drupal.behaviors.listmixer.listmixerActivate(preset);
              preset.activated = true;
              preset.deactivated = null;
              $(preset.interactions.interactions_target_id + "#selectable").selectable('destroy');      
            //}
          }
        });
  		  $(preset.interactions.interactions_target_id + "#selectable").disableSelection();
      }); 
  }
  else {
    $(preset.interactions.interactions_target_id + "#selectable").selectable('destroy');
  }
}